# PyQt5-Video-Book

## Video-001: PyQt5 How to Create a Window for opening an Excel file
> https://www.youtube.com/watch?v=Mv_oQ_OohPQ

## Video-002：App_002_Password_Generator_PyQt5
> https://youtu.be/hWGdSFH8haE

> https://youtu.be/1Y7EeL3J8C4

> https://youtu.be/Dw5wUUG97Sk

## Video-003：Menu structure for applications
> https://youtu.be/JKVq_-uuELI

## Video-004：Create shadow for widgets
> 

## Video-005：Create stylesheet for QComboBox
> https://youtu.be/S1bFw8Od0tU

## Video-006：Create stylesheet for QCalendarWidget
> https://youtu.be/y3agkV1Iju4

## Video-008: PyQt5 Project | Menu Structure for applications V2
> https://youtu.be/jWxNfb7Hng8

## Video-009: PyQt5 Project | Sidebar example of application
> https://youtu.be/7DXxQV47jOU

## Video：How to create live template of Pycharm
> https://www.youtube.com/watch?v=AHs0ZxMHQoc

## Video：PyQt5 First Software
> https://www.youtube.com/watch?v=li-PB6lQpRo
