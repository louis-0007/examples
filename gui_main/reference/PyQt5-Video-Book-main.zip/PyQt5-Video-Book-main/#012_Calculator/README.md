# PyQt5_Calculator

案例来源：
> https://realpython.com/python-pyqt-gui-calculator/#creating-a-calculator-with-python-and-pyqt

演示视频：
> https://youtu.be/H6MZHap7nKM
